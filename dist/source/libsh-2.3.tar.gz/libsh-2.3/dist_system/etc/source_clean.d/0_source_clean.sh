cd src
make clean
